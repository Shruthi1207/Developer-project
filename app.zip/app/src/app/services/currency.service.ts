import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class CurrencyService {
  headers = {
    'x-rapidapi-key': 'c378c2b78dmsh2244da6ca331f0ap12e5e0jsnc7c7c4a9dd28',
    'x-rapidapi-host': 'coinranking1.p.rapidapi.com',
  };
  constructor(private http: HttpClient) {}

  getCoins() {
    return this.http.get('https://coinranking1.p.rapidapi.com/coins', {
      headers: this.headers,
    });
  }

  getCoin(id: number) {
    return this.http.get(`https://coinranking1.p.rapidapi.com/coin/${id}`, {
      headers: this.headers,
    });
  }
}
