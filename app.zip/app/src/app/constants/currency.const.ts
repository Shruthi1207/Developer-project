export const CONSTANTS = {
    COINS: ['Bitcoin', 'Tether USD', 'Bitcoin Cash', 'Litecoin' ]
}