import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CurrencyService } from '../services/currency.service';

@Component({
  selector: 'app-currency-detail',
  templateUrl: './currency-detail.component.html',
  styleUrls: ['./currency-detail.component.scss'],
})
export class CurrencyDetailComponent implements OnInit {
  coin: any = {};
  coinId;
  dataLoading = false;
  constructor(
    private currencyService: CurrencyService,
    private route: ActivatedRoute
  ) {
    this.route.params.subscribe((params) => {
      this.coinId = params.id;
    });
  }

  ngOnInit() {
    if (this.coinId) {
      this.dataLoading = true;
      this.currencyService.getCoin(this.coinId).subscribe((response: any) => {
        this.dataLoading = false;
        const {
          data: { coin, base },
        } = response;
        this.coin = {
          ...coin,
          priceFormatted: parseFloat(coin.price).toFixed(2),
        };
      });
    }
  }

  getCoinsByAmount(amount: number) {
    const { price } = this.coin;
    if (!price) {
      return;
    }
    const totalCoins = amount * (1 / parseFloat(price));
    return totalCoins.toFixed(8);
  }
}
