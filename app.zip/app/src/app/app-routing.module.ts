import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CurrencyDetailComponent } from './currency-detail/currency-detail.component';
import { CurrencyListComponent } from './currency-list/currency-list.component';

const routes: Routes = [
  {
    path: 'coins',
    component: CurrencyListComponent,
  },
  {
    path: 'coin/:id',
    component: CurrencyDetailComponent,
  },
  {
    path: '',
    redirectTo: '/coins',
    pathMatch: 'full',
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
