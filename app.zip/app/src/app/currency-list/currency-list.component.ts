import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CONSTANTS } from '../constants/currency.const';
import { CurrencyService } from '../services/currency.service';

@Component({
  selector: 'app-currency-list',
  templateUrl: './currency-list.component.html',
  styleUrls: ['./currency-list.component.scss'],
})
export class CurrencyListComponent implements OnInit {
  coins = [];
  dataLoading = false;
  constructor(
    private currencyService: CurrencyService,
    private router: Router
  ) {}

  ngOnInit() {
    this.dataLoading = true;
    this.currencyService.getCoins().subscribe((response: any) => {
      this.dataLoading = false;
      const {
        data: { coins, base },
      } = response;

      this.coins = coins
        .filter((coin) => CONSTANTS.COINS.includes(coin.name))
        .map((coin) => {
          return {
            ...coin,
            priceFormatted: parseFloat(coin.price).toFixed(2),
          };
        });
    });
  }

  goToDetail(id: number) {
    this.router.navigate([`./coin/${id}`]);
  }
}
